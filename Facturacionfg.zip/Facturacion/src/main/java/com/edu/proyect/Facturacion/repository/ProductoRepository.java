package com.edu.proyect.Facturacion.repository;

import com.edu.proyect.Facturacion.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
}
