package com.edu.proyect.Facturacion.model;


import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@Entity
@Table(name = "detalle_factura")
public class Detalle_factura implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle_factura")
    private Integer id_detalle_factura;

    @Column(name = "cantidad")
    private Integer cantidad;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_factura", referencedColumnName = "id_factura")
    private Factura factura;


    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_producto", referencedColumnName = "id_producto")
    private Producto producto;
}
