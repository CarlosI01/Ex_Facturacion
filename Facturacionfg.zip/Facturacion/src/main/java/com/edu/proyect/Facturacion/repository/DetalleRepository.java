package com.edu.proyect.Facturacion.repository;

import com.edu.proyect.Facturacion.model.Detalle_factura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleRepository extends JpaRepository<Detalle_factura, Integer> {
}
