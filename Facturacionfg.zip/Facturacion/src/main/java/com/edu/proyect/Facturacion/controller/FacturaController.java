package com.edu.proyect.Facturacion.controller;

import com.edu.proyect.Facturacion.model.Factura;
import com.edu.proyect.Facturacion.service.FacturaService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class FacturaController {

    @Autowired
    private FacturaService facturaS;

    @GetMapping("/factura/requestAll")
    public ResponseEntity<List<Factura>> getAllFacture(){
      //  return ResponseEntity.ok(facturaS.findByAll());
       
			return ResponseEntity.status(HttpStatus.OK).body(facturaS.findByAll());
		
    }

    @GetMapping("/factura/searchById/{id}")
    public ResponseEntity<Factura> facturaById(@PathVariable("id") Integer id){
        return ResponseEntity.ok(facturaS.findById(id));
    }

    @PostMapping("/factura/save")
    public ResponseEntity<Factura> saveFacture(@RequestBody Factura factura){
        return new ResponseEntity<>(facturaS.save(factura), HttpStatus.CREATED);
    }

    @DeleteMapping("/factura/delete/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletefactura(@PathVariable("id") Integer id){
        facturaS.delete(id);
    }

    @PutMapping("/factura/update/{id}")
    public ResponseEntity<Factura> updateFactura(@RequestBody Factura factura, @PathVariable("id") Integer id){
        Factura facturaUp = facturaS.findById(id);
        if(facturaUp == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }else{
            try {
                facturaUp.setDetalle_factura(factura.getDetalle_factura());
                facturaUp.setFecha(factura.getFecha());
                facturaUp.setCliente(factura.getCliente());
                return ResponseEntity.ok(facturaS.save(facturaUp));
            }catch (Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
    }
}
