package com.edu.proyect.Facturacion.service;

import com.edu.proyect.Facturacion.model.Cliente;

public interface ClienteService extends GenericService<Cliente, Integer>{

    public Cliente buscarCliente(String cedula);
}
