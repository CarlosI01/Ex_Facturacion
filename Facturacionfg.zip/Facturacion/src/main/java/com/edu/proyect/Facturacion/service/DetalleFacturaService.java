package com.edu.proyect.Facturacion.service;

import com.edu.proyect.Facturacion.model.Detalle_factura;

public interface DetalleFacturaService extends GenericService<Detalle_factura, Integer>{
}
