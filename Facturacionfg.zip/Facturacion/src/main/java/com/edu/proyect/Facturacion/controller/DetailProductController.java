package com.edu.proyect.Facturacion.controller;

import com.edu.proyect.Facturacion.model.Detalle_factura;
import com.edu.proyect.Facturacion.service.DetalleFacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DetailProductController {

    @Autowired
    private DetalleFacturaService detalleFacturaS;

    @GetMapping("/detail/request")
    public ResponseEntity<List<Detalle_factura>> getAllDetails(){
        return ResponseEntity.ok(detalleFacturaS.findByAll());
    }

    @GetMapping("/detail/detaildById/{id}")
    public ResponseEntity<Detalle_factura> detailById(@PathVariable("id") Integer id){
        return ResponseEntity.ok(detalleFacturaS.findById(id));
    }

    @PostMapping("/detalle/save")
    public ResponseEntity<Detalle_factura> saveDetail(@RequestBody Detalle_factura detalle_factura){
        return new ResponseEntity<>(detalleFacturaS.save(detalle_factura), HttpStatus.CREATED);
    }

    @DeleteMapping("/detail/delete/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDetail(@PathVariable("id") Integer id){
    	detalleFacturaS.delete(id);
    }

    @PutMapping("detail/update/{id}")
    public ResponseEntity<Detalle_factura> updateDetail(@RequestBody Detalle_factura detalle_factura, @PathVariable("id") Integer id){
        Detalle_factura detailUp = detalleFacturaS.findById(id);
        if(detailUp == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }else{
            try {
                detailUp.setProducto(detalle_factura.getProducto());
                detailUp.setCantidad(detalle_factura.getCantidad());
                detailUp.setFactura(detalle_factura.getFactura());
                return ResponseEntity.ok(detalleFacturaS.save(detailUp));
            }catch (Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }

        }

    }

}
