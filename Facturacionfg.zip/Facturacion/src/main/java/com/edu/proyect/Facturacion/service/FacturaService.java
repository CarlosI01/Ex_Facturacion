package com.edu.proyect.Facturacion.service;

import com.edu.proyect.Facturacion.model.Factura;

public interface FacturaService extends GenericService<Factura, Integer>{
}
