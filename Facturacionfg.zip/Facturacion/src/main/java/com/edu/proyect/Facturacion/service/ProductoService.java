package com.edu.proyect.Facturacion.service;

import com.edu.proyect.Facturacion.model.Producto;

public interface ProductoService extends GenericService<Producto, Integer>{
}
