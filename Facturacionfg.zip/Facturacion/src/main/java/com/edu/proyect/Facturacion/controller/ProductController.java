package com.edu.proyect.Facturacion.controller;

import com.edu.proyect.Facturacion.model.Producto;
import com.edu.proyect.Facturacion.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductController {

    @Autowired
    private ProductoService productoS;

    @GetMapping("/producto/getAll")
    public ResponseEntity<List<Producto>> getAllProducts(){
        return ResponseEntity.ok(productoS.findByAll());
    }

    @GetMapping("/producto/productByID/{id}")
    public ResponseEntity<Producto> productById(@PathVariable("id") Integer id){
        return ResponseEntity.ok(productoS.findById(id));
    }

    @PostMapping("/producto/save")
    public ResponseEntity<Producto> saveProduct(@RequestBody Producto producto){
        return new ResponseEntity<>(productoS.save(producto), HttpStatus.CREATED);
    }

    @DeleteMapping("/producto/delete/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteProduct(@PathVariable("id") Integer id){
        productoS.delete(id);
    }

    @PutMapping("/producto/update/{id}")
    public ResponseEntity<Producto> updateProduct(@RequestBody Producto producto, @PathVariable("id") Integer id){
        Producto productoUp = productoS.findById(id);

        if(productoUp == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }else {
            try {
                productoUp.setNombre(producto.getNombre());
                productoUp.setPrecio(producto.getPrecio());
                productoUp.setStock(producto.getStock());
                productoUp.setDetalle_factura(producto.getDetalle_factura());
                return new ResponseEntity<>(productoS.save(productoUp), HttpStatus.CREATED);
            }catch (Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }


    }
}
