package com.edu.proyect.Facturacion.controller;

import com.edu.proyect.Facturacion.model.Cliente;
import com.edu.proyect.Facturacion.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ClienteController {

    @Autowired
    private ClienteService clienteS;

    @GetMapping("/client/listar")
    public ResponseEntity< List<Cliente>> obtenerLista() {
        return new ResponseEntity<>(clienteS.findByAll(), HttpStatus.OK);

    }

    @GetMapping("/client/search/{id}")
    public ResponseEntity<Cliente> getById(@PathVariable Integer id){
        return  new ResponseEntity<>(clienteS.findById(id), HttpStatus.OK);
    }

    @GetMapping("/client/searchPerCI/{cedula}")
    public ResponseEntity<Cliente> getClientPerCI(@PathVariable("cedula") String cedula){
        return ResponseEntity.ok(clienteS.buscarCliente(cedula));
    }

    @PostMapping("/client/crear")
    public ResponseEntity<Cliente> crear(@RequestBody Cliente c){
        return new ResponseEntity<>(clienteS.save(c), HttpStatus.CREATED);
    }

    @DeleteMapping("/client/delete/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Integer id) {
    	clienteS.delete(id);
    }

    @PutMapping("client/update/{id}")
    public ResponseEntity<Cliente> updateClient(@RequestBody Cliente cliente, @PathVariable("id") Integer id){
        Cliente clienteUp = clienteS.findById(id);

        System.out.println("Lo que no me debuelve"+clienteUp);
        if(clienteUp == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }else{
            try {
                clienteUp.setCedula(cliente.getCedula());
                clienteUp.setNombre(cliente.getNombre());
                clienteUp.setApellido(cliente.getApellido());
                clienteUp.setFactura(cliente.getFactura());
                return new ResponseEntity<>(clienteS.save(clienteUp), HttpStatus.CREATED);
            }catch (Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

    }
}
