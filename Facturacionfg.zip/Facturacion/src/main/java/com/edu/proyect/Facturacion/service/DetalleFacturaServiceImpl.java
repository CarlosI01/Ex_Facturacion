package com.edu.proyect.Facturacion.service;

import com.edu.proyect.Facturacion.model.Detalle_factura;
import com.edu.proyect.Facturacion.repository.DetalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

@Service
public class DetalleFacturaServiceImpl extends GenericServiceImpl<Detalle_factura, Integer> implements DetalleFacturaService{

    @Autowired
    private DetalleRepository detalleRepository;
    @Override
    public CrudRepository<Detalle_factura, Integer> getDao() {
        return detalleRepository;
    }
}
